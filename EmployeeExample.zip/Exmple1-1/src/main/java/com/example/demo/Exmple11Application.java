package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exmple11Application {

	public static void main(String[] args) {
		SpringApplication.run(Exmple11Application.class, args);
	}
	

}
