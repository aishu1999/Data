package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class ServiceEmployee {
	public List<Employeedata> employees = new ArrayList<>(Arrays.asList(
			new Employeedata(1,"sukanya",25000),
			new Employeedata(2,"supriya",25000),
			new Employeedata(3,"supraja",25000),
			new Employeedata(4,"monali",25000),
			new Employeedata(5,"Aishwarya",25000)
			
			)
			);
	
	
	    public List<Employeedata> getAllEmployeess()
	    {
	    	return employees;
	    }
	  
	    public Employeedata getEmployeedata(Integer id) {
	    	return employees.stream().filter(e -> e.getId().equals(id)).findFirst().get() ;
	    }
    
	    public void addEmployeedata(Employeedata employee)
	    {
	         employees.add(employee)	;
	    }
	    
	    public void deleteEmployeedata(Integer id)
	    {
	        employees.removeIf(e ->e.getId().equals(id))	;
	    }
	    
	    
}
