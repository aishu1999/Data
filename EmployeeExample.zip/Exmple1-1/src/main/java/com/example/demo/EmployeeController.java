package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController


public class EmployeeController {
	@Autowired
	private ServiceEmployee serviceEmployee;
	@GetMapping("/Employees")
	public List<Employeedata>getAllEmployees(){
		return serviceEmployee.getAllEmployeess();
	}
	
	
	@RequestMapping("/Employees/{id}")
    public Employeedata getEmployeedata(@PathVariable Integer id)
    {
	     return serviceEmployee.getEmployeedata(id) ;
    }
	
	
	//@Pathvariable Annotation
	@GetMapping("/Employees/{id}/{name}/{salary}")
	public Employeedata employeePathvariable(@PathVariable("id")Integer id ,@PathVariable("name") String name,@PathVariable("salary")Integer salary)  
	{
		return new Employeedata(id , name , salary);
	}
	
	
	//Build rest API to handle query parameters
	// ex: http://localhost:8080/Employees/query?id=5
	@GetMapping("/Employees/query")
	public Employeedata studentQueryParam( @RequestParam(name = "id") Integer id)
	{
		return serviceEmployee.getEmployeedata(id);
	}
	
	@PostMapping("/Employees")
	public void createEmployee(@RequestBody Employeedata employee)
	{
		serviceEmployee.addEmployeedata(employee);
	}
	

}
